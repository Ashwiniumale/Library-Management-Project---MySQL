CREATE DATABASE LIBRARY;

USE LIBRARY;

CREATE TABLE publisher(
Publisher_Name VARCHAR(250) PRIMARY KEY,
Publisher_Address VARCHAR(250),
Publisher_Phone VARCHAR(250));

SELECT * FROM publisher;

CREATE TABLE book(
Book_ID INT PRIMARY KEY AUTO_INCREMENT,
Title VARCHAR(250),
Publisher_Name VARCHAR(250),
FOREIGN KEY (Publisher_Name) REFERENCES publisher(Publisher_Name)
ON UPDATE CASCADE ON DELETE CASCADE); 

SELECT * FROM book;

CREATE TABLE authors(
Author_ID INT PRIMARY KEY AUTO_INCREMENT,
Book_ID INT,
Author_name VARCHAR(250),
FOREIGN KEY (Book_ID) REFERENCES book(Book_ID)
ON UPDATE CASCADE ON DELETE CASCADE); 

SELECT * FROM authors;

CREATE TABLE library_branch(
Branch_ID INT PRIMARY KEY AUTO_INCREMENT,
Branch_Name VARCHAR(250),
Branch_Address VARCHAR(250));

SELECT * FROM library_branch;

CREATE TABLE book_copies(
CopiesID INT PRIMARY KEY AUTO_INCREMENT,
Book_ID INT,
Branch_ID INT,
No_of_Copies INT,
FOREIGN KEY (Book_ID) REFERENCES book(Book_ID)
ON UPDATE CASCADE ON DELETE CASCADE,
FOREIGN KEY (Branch_ID) REFERENCES library_branch(Branch_ID)
ON UPDATE CASCADE ON DELETE CASCADE); 

SELECT * FROM book_copies;

CREATE TABLE borrower(
Card_no INT PRIMARY KEY AUTO_INCREMENT,
Borrower_Name VARCHAR(250),
Borrower_Address VARCHAR(250),
Borrower_Phone VARCHAR(20));

SELECT * FROM borrower;

CREATE TABLE book_loans(
Loans_ID INT PRIMARY KEY AUTO_INCREMENT,
Book_ID INT,
Branch_ID INT,
Card_No INT,
Date_Out DATE,
Due_Date DATE,
FOREIGN KEY (Book_ID) REFERENCES book(Book_ID)
ON UPDATE CASCADE ON DELETE CASCADE,
FOREIGN KEY (Branch_ID) REFERENCES library_branch(Branch_ID)
ON UPDATE CASCADE ON DELETE CASCADE,
FOREIGN KEY (Card_No) REFERENCES borrower(Card_No)
ON UPDATE CASCADE ON DELETE CASCADE); 

SELECT * FROM book_loans;

-- How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"?

SELECT Title, no_of_copies AS c
FROM book_copies AS bc
JOIN book AS b ON b.Book_ID = bc.Book_ID
JOIN library_branch AS lb ON lb.Branch_ID = bc.Branch_ID
WHERE (Title = "The Lost Tribe" AND lb.Branch_Name = "Sharpstown")
ORDER BY c DESC;

-- How many copies of the book titled "The Lost Tribe" are owned by each library branch?

SELECT Title, Branch_Name, SUM(no_of_copies) AS c
FROM book_copies AS bc
JOIN book AS b ON b.Book_ID = bc.Book_ID
JOIN library_branch AS lb ON lb.Branch_ID = bc.Branch_ID
WHERE Title = "The Lost Tribe" 
GROUP BY lb.Branch_Name
ORDER BY c DESC;

-- Retrieve the names of all borrowers who do not have any books checked out.

SELECT br.Borrower_Name FROM borrower as br
LEFT JOIN book_loans AS bl
ON br.Card_No = bl.Card_No
WHERE bl.Card_No IS NULL;

-- For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, the borrower's name, and the borrower's address. 

SELECT b.Title, lb.Branch_Name, br.Borrower_Name, br.Borrower_Address
FROM book_loans as bl
JOIN book as b ON b.Book_ID = bl.Book_ID
JOIN library_branch AS lb ON lb.Branch_ID = bl.Branch_ID
JOIN borrower AS br ON br.Card_No = bl.Card_No
WHERE (lb.Branch_Name = "Sharpstown" AND bl.Due_Date = "2018-03-02")
ORDER BY b.Title DESC;


-- For each library branch, retrieve the branch name and the total number of books loaned out from that branch.

SELECT lb.Branch_Name, COUNT(bl.Book_ID) AS total_books_loaned
FROM library_branch as lb
JOIN book_loans as bl
ON lb.Branch_ID = bl.Branch_ID
GROUP BY lb.Branch_Name;


-- Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out.

SELECT br.Borrower_Name, br.Borrower_Address, COUNT(bl.Card_No) AS c
FROM borrower AS br
JOIN book_loans as bl
ON br.Card_No = bl.Card_No
GROUP BY br.Card_No
HAVING c > 5
ORDER BY c DESC;


-- For each book authored by "Stephen King", retrieve the title and the number of copies owned by the library branch whose name is "Central"

SELECT b.Title, bc.No_of_Copies
FROM book as b
JOIN book_copies AS bc ON b.Book_ID = bc.Book_ID
JOIN authors AS ba on b.Book_ID - ba.Book_ID
JOIN library_branch AS lb ON lb.Branch_ID = bc.Branch_ID
WHERE (ba.Author_Name = "Stephen King" AND lb.Branch_Name = "Central");






